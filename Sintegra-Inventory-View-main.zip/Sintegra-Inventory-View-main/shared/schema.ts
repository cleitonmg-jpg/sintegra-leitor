export const APP_VERSION = "1.0.2";

import { z } from "zod";

export const inventoryItemSchema = z.object({
  id: z.string(),
  date: z.string(),
  productCode: z.string(),
  description: z.string(),
  unit: z.string(),
  ncm: z.string(),
  quantity: z.number(),
  unitPrice: z.number(),
  total: z.number(),
  ownership: z.number(),
  ownershipLabel: z.string(),
});

export type InventoryItem = z.infer<typeof inventoryItemSchema>;

export const companyInfoSchema = z.object({
  name: z.string(),
  cnpj: z.string(),
});

export type CompanyInfo = z.infer<typeof companyInfoSchema>;

export interface SintegraData {
  companyInfo: CompanyInfo;
  inventoryDate: string;
  items: InventoryItem[];
}
