import type { InventoryItem, CompanyInfo, SintegraData } from "@shared/schema";

function getOwnershipLabel(code: number): string {
  switch (code) {
    case 1:
      return "Propriedade do Informante e em seu poder";
    case 2:
      return "Propriedade do Informante em poder de terceiros";
    case 3:
      return "Propriedade de terceiros em poder do Informante";
    default:
      return "Desconhecido";
  }
}

function formatDate(rawDate: string): string {
  const cleaned = rawDate.replace(/-/g, "");
  if (cleaned.length === 8) {
    const year = cleaned.substring(0, 4);
    const month = cleaned.substring(4, 6);
    const day = cleaned.substring(6, 8);
    return `${day}-${month}-${year}`;
  }
  return rawDate;
}

export function parseSintegra(content: string): SintegraData {
  const lines = content.split(/\r?\n/);

  const record75Map: Map<string, { description: string; unit: string; ncm: string }> = new Map();
  let companyName10 = "";
  let companyName11 = "";
  let cnpj = "";
  let inventoryDate = "";
  const items: InventoryItem[] = [];

  for (const line of lines) {
    if (line.length < 2) continue;
    const recordType = line.substring(0, 2);

    if (recordType === "10") {
      cnpj = line.substring(2, 16).trim();
      companyName10 = line.substring(30, 65).trim();
    }

    if (recordType === "11") {
      companyName11 = line.substring(2, 49).trim();
    }

    if (recordType === "75") {
      const productCode = line.substring(18, 32).trim();
      const ncm = line.substring(32, 40).trim();
      const description = line.substring(40, 93).trim();
      const unit = line.substring(93, 99).trim();
      record75Map.set(productCode, { description, unit, ncm });
    }
  }

  const companyName = companyName10 || companyName11;
  const companyInfo: CompanyInfo = { name: companyName, cnpj };

  let hasRecord74 = false;
  for (const line of lines) {
    if (line.length < 2) continue;
    const recordType = line.substring(0, 2);

    if (recordType === "74") {
      hasRecord74 = true;
      const rawDate = line.substring(2, 10).trim();
      const formattedDate = formatDate(rawDate);
      if (!inventoryDate) inventoryDate = formattedDate;

      const productCode = line.substring(10, 24).trim();
      const rawQty = line.substring(24, 37).trim();
      const rawTotal = line.substring(37, 50).trim();
      const ownershipCode = parseInt(line.substring(50, 51).trim()) || 1;

      const quantity = parseInt(rawQty, 10) / 1000;
      const total = parseInt(rawTotal, 10) / 100;
      const unitPrice = quantity > 0 ? total / quantity : 0;

      const productInfo = record75Map.get(productCode);
      const description = productInfo?.description || "Produto nao encontrado";
      const unit = productInfo?.unit || "UN";
      const ncm = productInfo?.ncm || "";

      items.push({
        id: `${productCode}-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
        date: formattedDate,
        productCode,
        description,
        unit,
        ncm,
        quantity: Math.round(quantity * 1000) / 1000,
        unitPrice: Math.round(unitPrice * 100) / 100,
        total: Math.round(total * 100) / 100,
        ownership: ownershipCode,
        ownershipLabel: getOwnershipLabel(ownershipCode),
      });
    }
  }

  // Se não houver registro 74, carregar todos os produtos do registro 75
  if (!hasRecord74) {
    record75Map.forEach((info, code) => {
      items.push({
        id: `${code}-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
        date: "",
        productCode: code,
        description: info.description,
        unit: info.unit,
        ncm: info.ncm,
        quantity: 0,
        unitPrice: 0,
        total: 0,
        ownership: 0,
        ownershipLabel: "Apenas Cadastro",
      });
    });
  }

  return {
    companyInfo,
    inventoryDate: inventoryDate || "N/A",
    items,
  };
}
